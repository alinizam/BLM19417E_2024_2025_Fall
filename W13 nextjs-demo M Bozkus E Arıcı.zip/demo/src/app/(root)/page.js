import React from 'react'

export default function Home() {
  return (
    <div>Welcome to our demo app.</div>
  )
}
